from functools import reduce

def sequence_generator(*sequences):
    for seq in sequences:
        for item in seq:
            yield item

def combine_sequences(sequences):
    # Генератор для объединения последовательностей
    combined = sequence_generator(*sequences)
    
    # Применяем filter для отбора только чисел
    filtered_numbers = filter(lambda x: isinstance(x, (int, float)), combined)
    
    # Применяем map для возведения в квадрат
    squared_numbers = map(lambda x: x ** 2, filtered_numbers)
    
    # Применяем reduce для суммирования
    total_sum = reduce(lambda x, y: x + y, squared_numbers, 0)
    
    return total_sum

seq1 = [1, 3, 2]
seq2 = [3, 1, 2]
seq3 = [1, 3, 2]

result = combine_sequences([seq1, seq2, seq3])
print(result)


