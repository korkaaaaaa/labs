import sys
from io import StringIO

def dekorator(func):
    def wrapper(*args, **kwargs):       
        sys.stdout = StringIO()
    return wrapper

def hp_tracker():
    hp = 100 

    def modify_hp(amount):
        nonlocal hp  
        hp += amount
        if hp > 100:
            hp = 100
        elif hp < 0:
            hp = 0
        return hp

    return modify_hp

hero_hp = hp_tracker()

#@dekorator
def print_hp():
    print(f"Текущие HP героя: {hero_hp(0)}")

print_hp()
hero_hp(-70)
print_hp()
hero_hp(30)
print_hp()