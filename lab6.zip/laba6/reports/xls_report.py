import openpyxl

def save_to_excel(device, energy, cost, filename="report.xlsx"):
    """
    Создаёт файл .xls с результатами расчёта.
    """
    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = "Энергопотребление"
    
    ws.append(["Прибор", "Энергия (кВт·ч)", "Стоимость (руб.)"])
    ws.append([device, energy, cost])
    
    wb.save(filename)