import tkinter as tk
from tkinter import messagebox
from devices.iron import calculate_iron
from devices.tv import calculate_tv
from devices.washing_machine import calculate_washing_machine
from reports.xls_report import save_to_excel

# Функция для расчёта
def calculate():
    device = device_var.get()
    power = float(power_entry.get())
    hours = float(hours_entry.get())
    rate = float(rate_entry.get())

    if device == "Утюг":
        energy, cost = calculate_iron(power, hours, rate)
    elif device == "Телевизор":
        energy, cost = calculate_tv(power, hours, rate)
    elif device == "Стиральная машина":
        energy, cost = calculate_washing_machine(power, hours, rate)
    else:
        messagebox.showerror("Ошибка", "Выберите прибор!")
        return
    
    global calculated_energy, calculated_cost
    calculated_energy = energy
    calculated_cost = cost

    result_label.config(text=f"Потребление: {energy:.2f} кВт·ч\nСтоимость: {cost:.2f} руб.")

# Функция для сохранения отчёта
def save_report():
    device = device_var.get()

    if 'calculated_energy' not in globals() or 'calculated_cost' not in globals():
        messagebox.showerror("Ошибка", "Сначала выполните расчёт!")
        return

    energy = calculated_energy
    cost = calculated_cost

    # Сохраняем отчёт в Excel
    save_to_excel(device, energy, cost)
    messagebox.showinfo("Отчёт", "Отчёт сохранён!")

# Создание окна
root = tk.Tk()
root.title("Калькулятор потребления электроэнергии")

# Выбор прибора
device_var = tk.StringVar()
device_label = tk.Label(root, text="Выберите прибор:")
device_label.pack()

device_menu = tk.OptionMenu(root, device_var, "Утюг", "Телевизор", "Стиральная машина")
device_menu.pack()

# Ввод мощности
power_label = tk.Label(root, text="Мощность (кВт):")
power_label.pack()
power_entry = tk.Entry(root)
power_entry.pack()

# Ввод времени работы
hours_label = tk.Label(root, text="Время работы (часы):")
hours_label.pack()
hours_entry = tk.Entry(root)
hours_entry.pack()

# Ввод тарифа
rate_label = tk.Label(root, text="Тариф (руб/кВт·ч):")
rate_label.pack()
rate_entry = tk.Entry(root)
rate_entry.pack()

# Кнопка для расчёта
calc_button = tk.Button(root, text="Рассчитать", command=calculate)
calc_button.pack()

# Вывод результата
result_label = tk.Label(root, text="Потребление: \nСтоимость: ")
result_label.pack()

# Кнопка сохранения отчёта
save_button = tk.Button(root, text="Сохранить отчёт", command=save_report)
save_button.pack()

# Запуск окна
root.mainloop()
