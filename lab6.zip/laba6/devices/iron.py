def calculate_iron(power, hours, cost_per_kwh):
    energy_kwh = (power / 1000) * hours  # Переводим Вт в кВт
    cost = energy_kwh * cost_per_kwh  # Стоимость энергии
    return round(energy_kwh, 2), round(cost, 2)  # Возвращаем с округлением до 2 знаков

"""
    power_kw: Мощность утюга (в кВт)
    hours: Время работы (в часах)
    rate: Тариф за электроэнергию (руб/кВт·ч)
"""